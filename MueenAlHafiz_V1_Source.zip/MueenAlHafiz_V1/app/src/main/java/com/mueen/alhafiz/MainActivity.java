package com.mueen.alhafiz;

import android.app.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import android.content.*;import java.util.*;

public class MainActivity extends Activity {
    MushafView mushaf; TextView count;
    int visibleWords=3;
    @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
    TextView tv(String s,int size){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(45,38,27));t.setGravity(Gravity.CENTER);t.setPadding(12,12,12,12);return t; }
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
    void showHome(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,30,24,24);root.setBackgroundColor(Color.rgb(247,242,229));
        TextView title=tv("مُعين الحافظ",30); title.setTextColor(Color.rgb(115,83,20)); root.addView(title,new LinearLayout.LayoutParams(-1,70));
        TextView sub=tv("القرآن للحفظ والمراجعة",18);root.addView(sub,new LinearLayout.LayoutParams(-1,50));
        String[] items={"📖  ابدأ الحفظ","🔄  مراجعة المحفوظ","📚  القرآن الكريم","🔢  إحصاء الألفاظ","🧩  المتشابهات","📜  التفسير","🎧  المقرئون","⚙️  الإعدادات"};
        for(int i=0;i<items.length;i++){TextView x=tv(items[i],20);x.setBackground(bg(Color.WHITE,24));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,58);p.setMargins(0,7,0,7);root.addView(x,p);if(i==0)x.setOnClickListener(v->showMushaf());}
        setContentView(root);
    }
    void showMushaf(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(238,232,216));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(8,4,8,4);
        Button back=new Button(this);back.setText("رجوع");back.setOnClickListener(v->showHome());bar.addView(back,new LinearLayout.LayoutParams(85,55));
        count=tv("الكلمات الظاهرة: "+visibleWords,15);bar.addView(count,new LinearLayout.LayoutParams(0,55,1));
        Button less=new Button(this);less.setText("−");less.setOnClickListener(v->{if(visibleWords>1){visibleWords--;update();}});bar.addView(less,new LinearLayout.LayoutParams(55,55));
        Button more=new Button(this);more.setText("+");more.setOnClickListener(v->{if(visibleWords<10){visibleWords++;update();}});bar.addView(more,new LinearLayout.LayoutParams(55,55));
        root.addView(bar);mushaf=new MushafView(this);root.addView(mushaf,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint=tv("اسحب للتنقل • قرّب بإصبعين • اضغط على بداية الآية للكشف",14);root.addView(hint,new LinearLayout.LayoutParams(-1,48));setContentView(root);
    }
    void update(){count.setText("الكلمات الظاهرة: "+visibleWords);mushaf.setVisible(visibleWords);}
    public static class MushafView extends View{
        Paint p=new Paint(3);float scale=1f,dx=0,dy=0;float lx,ly;int words=3;boolean dragging=false;MushafView(Context c){super(c);p.setTypeface(Typeface.create("serif",Typeface.NORMAL));setBackgroundColor(Color.rgb(252,249,240));}
        void setVisible(int n){words=n;invalidate();}
        protected void onDraw(Canvas c){super.onDraw(c);c.save();c.translate(dx,dy);c.scale(scale,scale);float w=getWidth()/scale;float h=getHeight()/scale; p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.rgb(164,132,64));c.drawRect(18,18,w-18,h-18,p);p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(65,55,38));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(24);c.drawText("صفحة المصحف — نموذج V1",w/2,60,p);p.setTextSize(17);c.drawText("واجهة الحفظ مع الحفاظ على مواضع الكلمات",w/2,92,p);
            float y=145; for(int line=0;line<13;line++){StringBuilder s=new StringBuilder();for(int i=0;i<words;i++)s.append("كلمة ").append(i+1).append("   ");s.append("      •••••••••••••••••••");c.drawText(s.toString(),w/2,y,p);y+=43;}
            p.setTextSize(13);p.setColor(Color.rgb(120,95,40));c.drawText("سيُستبدل هذا النموذج ببيانات صفحات المصحف المعتمدة دون إعادة تنضيد",w/2,h-45,p);c.restore();}
        public boolean onTouchEvent(android.view.MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:lx=e.getX();ly=e.getY();dragging=true;return true;case MotionEvent.ACTION_MOVE:if(dragging){dx+=e.getX()-lx;dy+=e.getY()-ly;lx=e.getX();ly=e.getY();invalidate();}return true;case MotionEvent.ACTION_UP:dragging=false;return true;}return true;}
    }
}
